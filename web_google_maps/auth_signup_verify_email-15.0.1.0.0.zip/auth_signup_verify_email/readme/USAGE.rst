To use this module, you need to:

* Log out.
* `Sign up </web/signup>`_ with a valid email.
