This module extends the functionality of public sign up to force users to
provide a valid email address.

To achieve this, users are not required to provide a password at
sign up: they are asked for only at first login attempt.
